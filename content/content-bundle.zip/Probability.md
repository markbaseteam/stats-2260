**Probability**
--

The most basic probability questions are those that occur when we have equally likely outcomes

$$ \text{P(event) = } \frac{\text{\# of outcomes resulting in the event}}{\text{\# of total possible outcomes}} $$

**Example:** Flip a fair coin once. What is the probability of heads?
$$\text{P(H) = } \frac{1}{2} = 0.5$$


The problem is it can be difficult to count the # of outcomes for the numerator and/or denominator.

---

**Example:** Flip a fair coin three times, what is the probability of getting exactly 2 heads?

$$\text{P(2 heads) = } \frac{3}{8} = 0.375$$

**The multiplication rule:** 

$$\frac {\text{2 possibilities on 1st flip } \times \text{2 possibilities on 2nd flip } \times \text{2 possibilities on 3rd flip}}{\text{8 total outcomes}}$$

| H     | H   | H   |
| ----- | --- | --- |
| ==H== | ==H==   | ==T==   |
| ==H==     | ==T==   | ==H==   |
| ==T==     | ==H==   | ==H==   |
| T     | T   | H   |
| T     | H   | T   |
| H     | T   | T   |
| T     | T   | T   |

---

The probability of any event must be a number between 0 and 1 (inclusive)

$$ 0 \le P(A) \le 1$$

---

| Permutations                                                       | Combinations                                                                  |
| ------------------------------------------------------------------ | ----------------------------------------------------------------------------- |
| The number of ways to select r items from n items if order matters | The number of ways of selecting r items from n items if order does not matter |
| $$_nP_{r}= \frac{n!}{(n-r)!}$$                                     | $$_nC_{r} = \frac{n!}{r!(n-r)!}$$                                                                              |

---
**Marginal Probability:** The probability of a single event.

$$P(Survived)$$
$$\text{P(1st class)}$$
---

**Joint Probability:** The probability of two events both happening

$$\text{P(1st class AND Survived)}$$

---

**Conditional Probability:** The probability of A given B. The probability that event A happens given that event B has happened. (*1st class determines denominator*)

$$\text{P(Survived | 1st class)}$$

---
**Conditional Probability Formula**

$$P(A|B) = \frac{\text{P(A AND B)}}{P(B)}$$

---
**Definition of Independent Events**

If events A and B are independent, then: 

$$P(A|B) = P(A)$$

---
**The General Addition Rule**

$$\text{P(A OR B) = P(A) + P(B) - P(A AND B)}$$
Events A and B are called disjoint (mutually exclusive) if P(A AND B) = 0

![[Pasted image 20220924212911.png]]

---
**Addition Rule for Disjoint Events**

$$\text{P(A OR B) = P(A) + P(B)}$$

---
**The General Addition Rule for 3 Events** 
$$\text{P(A OR B OR C) = P(A) + P(B) + P(C) - P(A AND B) - P(A AND C) - P(B AND C) + P(A AND B AND C)}$$
![[Pasted image 20220924213343.png]]

---

**If A and B are independent:**

$$\text{P(A+B) = P(A)}$$

---
**Conditional Probability Formula**

$$\text{P(A|B) = } \frac{\text{P(A AND B)}}{P(B)}$$

---
**The General Multiplication Rule**

$$\text{P(A AND B) = P(B) * P(A|B)}$$
$$\text{P(A AND B) = P(A) * P(B|A)}$$

---
**The Multiplication Rule for independent events**
If A and B are independent then:

$$\text{P(A AND B) = P(A) * P(B)}$$
*recall if A and B are independent, then:*
$$\text{P(A+B) = P(A)}$$
