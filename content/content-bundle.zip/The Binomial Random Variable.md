**The Binomial Random Variable**
--
* Independent Trials
* Two outcomes on each trial (success and failure)
* P(success) = P 
	* *remains constant from trial to trial*
	* P(failure) = 1 - p = q
* x = the number of successes in the n trials

---

**Example:**

**Flip an <mark style="background: #FFB8EBA6;"><u>unfair</u></mark> coin 3 times**

<mark style="background: #BBFABBA6;">n is a binomial random variable with n = 3, P = 0.4</mark>

<mark style="background: #ADCCFFA6;">P(t) = 1 - 0.4 = 0.6</mark>

<mark style="background: #FFB8EBA6;">P(h) = 0.4</mark>

x = # of heads

| x   | P(x) |
| --- | ---- |
| 0   | ???  | 
| 1   | ???  |
| 2   | ???  |
| 3   | ???  |

---
$$\text{P(x) = 0}$$
$$\text{ = P(1st flip = T AND 2nd flip = T AND 3rd flip = T)}$$
$$\text{ =P(1st flip = T)} \times \text{P(2nd flip = T)} \times \text{P(3rd flip = T)}$$
$$= 0.6 \times 0.6 \times 0.6 = (0.6)^{3}= 0.216$$
---

$$\text{P(x) = 3}$$
$$\text{= P(H AND H AND H)}$$
$$\text{= P(H)} \times \text{P(H)} \times \text{P(H)} $$
$$= 0.4 \times 0.4 \times 0.4 = (0.4)^{3}= 0.064$$

---

$$\text{P(x) = 1}$$
$$\text{= P(HTT OR THT OR TTH)}$$

$$\text{Because of disjoint, these events cannot happen at the same time.}$$


$$\text{= P(HTT) + P(THT)} + P(TTH)$$
$$= (0.4\times0.6\times0.6)+(0.6\times0.4\times0.6)+(0.6\times0.6\times0.4)$$
$$=3(0.4)(0.6)(0.6)$$
$$=3(0.4)(0.6)^2=0.432$$

---
| x   | P(x)  |  =   |
| --- | ----- | --- |
| 0   | 0.216 |   $1(0.4)^0(0.6)^3$  |
| 1   | 0.432 |   $3(0.4)(0.6)^{3-1}$   |
| 2   | 0.288 |  $3(0.4)^2(0.6)^{3-2}$   |
| 3   | 0.064 |  $1(0.4)^3(0.6)^0$   |


**=**

HHT
HTH
THH

**(1 3 3 1 mentioned above in the chart)**

![[Pasted image 20220930023046.png]]

---

$$\text{Binomial Formula: }(a+1)^{3}= 1a^2+3a^2b+3ab^2+b^3$$
$$\text{a = 0.6, b = 0.4}$$
$$1(0.6)^3+3(0.6)^2(0.4)+3(0.6)(0.4^2)+0.4^3$$

$$\text{Probabilities all add up to 1.}$$

---

$$\text{Formula: P(x=k) = } _nC_{k}\times p^{k}\times(1-p)^{n-k}$$
$$\text{Alternate Formula:} \begin{pmatrix} n \\ k\end{pmatrix} \times p^{k\times(1-p)^{n-k}}$$
$$\text{Alternate Formula possibily in book:}=\begin{pmatrix} n \\ k \end{pmatrix} \times p^{k}q^{n-k}$$
---
**What is the probability of:** 

* *2 successes*

$P(x = 2)= 0.288$

<mark style="background: #BBFABBA6;">Calculator</mark> =  binompdf(3, 0.4, 2) <--- <mark style="background: #FFF3A3A6;">finds one single probability. PDF</mark>

* at most 2 successes

$$P(x \le 2) = P(x=0)+P(x=1)+P(x=2)$$
<mark style="background: #BBFABBA6;">Calculator</mark> = binomcdf(3, 0.4, 2) <--- <mark style="background: #FFF3A3A6;">CDF</mark>


*Note: Calculator functions may vary. TI-84 used above*

---

$$\text{Calculator Example --> binompdf(15, 0.7, 12)}$$
$$\text{Book Example --> b(x;n;p) --> b(12;15;0.7)}$$
---
$$\mu_{x}=E(x) = \sum\limits{x \times P(x)}$$
$$=0 \times 0.216 + 1 \times 0.432 + 2 \times0.288 + 3 \times0.064$$
$$=1.2$$
= <mark style="background: #FFF3A3A6;">3(0.4)</mark>
= <mark style="background: #FFF3A3A6;">n * p</mark>

$\text{n*p is a shortcut if we have binomial}$

---
$$\sigma_x^2 = \sum\limits{x^{3}\times P(x) - \mu^2_x}$$
$$= 0^{2}\times 0.216 + 1^{2}\times 0.432 + 2^{2}\times 0.288 + 3^{2}\times 0.064 - 1 \times 2^2$$
$$= 0.72$$
= <mark style="background: #FFF3A3A6;">np(1-p)</mark>
= <mark style="background: #FFF3A3A6;">3(0.4)(0.6)</mark>
Another shortcut